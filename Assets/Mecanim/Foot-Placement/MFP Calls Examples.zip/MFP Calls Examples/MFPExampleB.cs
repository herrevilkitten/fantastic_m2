using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
public class MFPExampleB : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    public float FeetOffset;					// Fine adjustment of feet.
    public Transform Hips;					// The Pelvis joint, just a height reference.
    public Transform LeftToe;				// Foot joint used as foot length reference.
    public Transform RightToe;				// Foot joint used as foot length reference.
    public Transform LeftTip;				// Empty GameObject, Joints' world space reference.
    public Transform RightTip;				// Empty GameObject, Joints' world space reference.
    private Animator Actor;					// The Animator component attached.
    //
    void Start() {
        Actor = GetComponent<Animator>();
    }
    //
    void OnAnimatorIK(int Layer) {
        Actor.FootPlacement(Do,HeelOffset,FeetOffset,Actor.GetFloat("Speed"),LeftToe,RightToe,LeftTip,RightTip);
    }
}