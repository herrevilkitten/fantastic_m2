using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
public class MFPExampleE : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    public float FeetOffset;					// Fine adjustment of feet.
    public Transform LeftToe;				// Foot joint used as foot length reference.
    public Transform RightToe;				// Foot joint used as foot length reference.
    public Transform LeftTip;				// Empty GameObject, Joints' world space reference.
    public Transform RightTip;				// Empty GameObject, Joints' world space reference.
    public LayerMask FPMask;				// Layer mask to filter feet raycasting.
    private Animator Actor;					// The Animator component attached.
    //
    void Start() {
        Actor = GetComponent<Animator>();
    }
    //
    void OnAnimatorIK(int Layer) {
    	// We want to ignore some physics layers here, so we gonna usa a LayerMask to make sure feet will raycast only what we want to:
    	Vector2 Curve = new Vector2(Actor.GetFloat("LFP"),Actor.GetFloat("RFP"));
    	Actor.FootPlacement(Do,HeelOffset,FeetOffset,Curve,Curve,LeftToe,RightToe,LeftTip,RightTip,FPMask);
    }
}