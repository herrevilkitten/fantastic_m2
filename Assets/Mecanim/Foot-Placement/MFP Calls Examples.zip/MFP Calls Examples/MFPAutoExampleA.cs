using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
public class MFPAutoExampleA : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    public float FeetOffset;					// Fine adjustment of feet.
    private Animator Actor;					// The Animator component attached.
    //
    void Start() {
        Actor = GetComponent<Animator>();
    }
    //
    void OnAnimatorIK(int Layer) {
    	// Here we have a generic group of animations so we really don't want to mess with curves;
    	// Still the same results are achieved unless animations are exotic, not default run/walk patern.
    	// We also in this case don't want to reference any empty transform for any reason so this method override is perfect for what we want:
    	Actor.FootPlacement(Do,HeelOffset,FeetOffset);
		// Understand however that in this case everything in the simulation is automated and you won't be able to modify anything within its behavior.
    }
}