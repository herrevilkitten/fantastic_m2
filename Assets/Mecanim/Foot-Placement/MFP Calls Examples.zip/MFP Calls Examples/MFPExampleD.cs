using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(CharacterController))]
public class MFPExampleD : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    public float FeetOffset;					// Fine adjustment of feet.
    public Transform LeftToe;				// Foot joint used as foot length reference.
    public Transform RightToe;				// Foot joint used as foot length reference.
    public Transform LeftTip;				// Empty GameObject, Joints' world space reference.
    public Transform RightTip;				// Empty GameObject, Joints' world space reference.
    private Animator Actor;					// The Animator component attached.
    private CharacterController Controller;	// The CharacterController component attached.
    private float CC_Height;
    //
    void Start() {
        Actor = GetComponent<Animator>();
        Controller = GetComponent<CharacterController>();
        CC_Height = Controller.height;
    }
    //
    void OnAnimatorIK(int Layer) {
    	// This example is for extreme situations where both IKs and Character Controller are colliding with a surface
    	// where inclination is so deep that foot bones won't be able to reach its IK goal.
    	// To solve this, we simply add character's controller height based on distance of foot bone and its IK goal distance:
    	Vector2 Curve = new Vector2(Actor.GetFloat("LFP"),Actor.GetFloat("RFP"));
    	Vector2 Offset = Actor.FootPlacementV2(Do,HeelOffset,FeetOffset,Curve,Curve,LeftToe,RightToe,LeftTip,RightTip);
    	if (Offset.x > Offset.y) {
    		Controller.height = CC_Height-Offset.x;
    	} else if (Offset.y > Offset.x) {
    		Controller.height = CC_Height-Offset.y;
    	} else if (!(Controller.collisionFlags == CollisionFlags.CollidedBelow)) {Controller.height = CC_Height;}
    	// This may require from extra work to identify if original size doesn't goes through collider position, else
    	// your character may fall through colliders when doing this. But for most cases simply reseting its scale is enough.
    }
}