using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
public class MFPExampleA : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    private Animator Actor;					// Animator component attached.
    //
    void Start() {
        Actor = GetComponent<Animator>();
    }
    //
    void OnAnimatorIK(int Layer) {
        Actor.FootPlacement(Do,HeelOffset);
    }
}