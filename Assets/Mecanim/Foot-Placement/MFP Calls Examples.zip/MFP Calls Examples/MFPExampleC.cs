using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
public class MFPExampleC : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    public float FeetOffset;					// Fine adjustment of feet.
    public Transform LeftToe;				// Foot joint used as foot length reference.
    public Transform RightToe;				// Foot joint used as foot length reference.
    public Transform LeftTip;				// Empty GameObject, Joints' world space reference.
    public Transform RightTip;				// Empty GameObject, Joints' world space reference.
    private Animator Actor;					// The Animator component attached.
    //
    void Start() {
        Actor = GetComponent<Animator>();
    }
    //
    void OnAnimatorIK(int Layer) {
    	// Let's setup two floats on our Mecanim controller: 'LFP' & 'RFP'.
    	// These floats we then control by FBX Curves (check Mecanim docs) and control IK weights through them.
    	// Starting values as 1 gives better results than starting from 0f.
    	Vector2 Curve = new Vector2(Actor.GetFloat("LFP"),Actor.GetFloat("RFP"));
    	Actor.FootPlacement(Do,HeelOffset,FeetOffset,Curve,LeftToe,RightToe,LeftTip,RightTip);
    }
}