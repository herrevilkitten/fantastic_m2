using UnityEngine;
using System.Collections;

// Example of how to use the MFP class.
// Add this to your Mecanim Character and follow the Guide to understand how to use it.

[RequireComponent(typeof(Animator))]
public class MFPAutoExampleB : MonoBehaviour {
    public bool Do;							// If need to turn off placement for any reason.
    public float HeelOffset;					// Fine adjustment of heels.
    public float FeetOffset;					// Fine adjustment of feet.
    public AnimationCurve FPL_Curve;		// A way to sample curves for left IK Weights.
    public AnimationCurve FPR_Curve;		// A way to sample curves for right IK Weights.
    private Animator Actor;					// The Animator component attached.
    //
    void Start() {
        Actor = GetComponent<Animator>();
    }
    //
    void OnAnimatorIK(int Layer) {
    	// Here we have a generic group of animations so we really don't want to mess with curves;
    	// Still the same results are achieved unless animations are exotic, not default run/walk patern.
    	// We also in this case don't want to reference any empty transform for any reason so this method override is perfect for what we want:
    	Actor.FP_LeftCurve(FPL_Curve); Actor.FP_RightCurve(FPR_Curve);
    	Actor.FootPlacement(Do,HeelOffset,FeetOffset);
		// Telling the method to use our custom public curves, we can modify the way our animation clips will interact with the simulation.
		// By now there are many method variations to achieve the same goal, but I am quite sure this one may be the best option for most projects so far.
    }
}